To use any parts of my theme (theme itself, shellstyles, etc.) in your project, Please let me know first.

2022-2025 vaporvance.
-----------------------------------------------------------

Credits and Special thanks for

• Microsoft for original themes, wallpapers and sounds from Windows Vista and Windows 7

• OjasK for Control Panel Sidebar idea
	https://github.com/ojask

• angelbruni for Command bar icons restoration
	https://github.com/angelbruni

-----------------------------------------------------------
Windows 7, Windows Vista and/or Windows logo are trademarks/registered trademarks of Microsoft.
Not affiliated with Microsoft in any way.
-----------------------------------------------------------