To use any parts of my theme (theme itself, shellstyles, etc.) in your project, Please let me know first.

2022-2025 vaporvance.
-----------------------------------------------------------

Credits and Special thanks for

• Microsoft for original themes, wallpapers and sounds from Windows XP

• angelbruni for Command bar/Common Task Pane icons restoration
	https://github.com/angelbruni

• Travis for discovering an accurated Common Task Pane animation

-----------------------------------------------------------
Windows XP and/or Windows logo are trademarks/registered trademarks of Microsoft.
-----------------------------------------------------------